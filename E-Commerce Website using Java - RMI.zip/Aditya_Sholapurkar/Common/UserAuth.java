package Common;

import java.rmi.Remote;
import java.rmi.RemoteException;

public interface UserAuth extends Remote {
    boolean loginUser(User user, String loginType) throws RemoteException;
    boolean isCustomer (String username) throws RemoteException;
    boolean isAdministrator(String username) throws RemoteException;
    void addCustomer(User user) throws RemoteException;
    void addAdministrator(User user) throws RemoteException;
    void removeCustomer(String username) throws RemoteException;
}