package Common;

import java.io.Serializable;

public class StoreItem implements Serializable {
    private String name;
    private double price;
    private int quantity;

    // Constructor with parameters
    public StoreItem(String name, double price, int quantity) {
        this.name = name;
        this.price = price;
        this.quantity = quantity;
    }

    public StoreItem(StoreItem item) {
        this.name = item.getName();
        this.quantity = item.getQuantity();
        this.price = item.getPrice();
    }

    // Default constructor
    public StoreItem() {
        this("", 0.0, 0); // Calling another constructor to set default values
    }

    // Getter methods
    public String getName() {
        return name;
    }

    public double getPrice() {
        return price;
    }

    public int getQuantity() {
        return quantity;
    }

    // Setter methods
    public void setName(String name) {
        this.name = name;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    // toString method for displaying Item details
    @Override
    public String toString() {
        return "Item [name=" + name + ", price=" + price + ", quantity=" + quantity + "]";
    }
}
