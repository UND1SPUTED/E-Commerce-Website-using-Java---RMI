package Common;

public interface Command {
    void execute();
}
