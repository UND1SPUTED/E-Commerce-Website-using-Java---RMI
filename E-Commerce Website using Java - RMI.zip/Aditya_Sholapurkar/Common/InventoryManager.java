package Common;

import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.List;

public interface InventoryManager extends Remote {
    List<StoreItem> getItems() throws RemoteException;
    boolean isItemPresent(String name) throws RemoteException;
    void addItem(StoreItem product) throws RemoteException;
    void removeItem(String name) throws RemoteException;
    void updateItem(String name, double newPrice, int quantity) throws RemoteException;
    StoreItem getItemByName(String name) throws RemoteException;
    void purchaseItems(List<StoreItem> cart) throws RemoteException;
}