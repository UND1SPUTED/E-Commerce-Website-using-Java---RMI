package Common;

import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.List;

public class ShoppingCart {
    private final List<StoreItem> cartStoreItems;

    public ShoppingCart() {
        this.cartStoreItems = new ArrayList<>();
    }

    public List<StoreItem> getCartItems() {
        return new ArrayList<>(cartStoreItems); // Return a copy to ensure encapsulation
    }

    public void addToCart(StoreItem storeItem) throws RemoteException {
        if (storeItem != null) {
            cartStoreItems.add(storeItem);
        }
    }

    public void purchaseCart() throws RemoteException {
        cartStoreItems.clear(); // Clear the cart after purchase
    }

    public double getCartTotal() throws RemoteException {
        return cartStoreItems.stream()
                .mapToDouble(StoreItem::getPrice)
                .sum(); // Use streams for concise and readable aggregation
    }

    public void removeFromCart(String name) throws RemoteException {
        cartStoreItems.removeIf(item -> item.getName().equalsIgnoreCase(name)); // Directly remove the item, assuming equals() is properly overridden in Item
    }

    public boolean isItemInCart(String name) throws RemoteException {
        return cartStoreItems.stream().anyMatch(item -> item.getName().equalsIgnoreCase(name)); // Use contains() to check if an item is in the cart
    }

    public boolean isEmpty() {
        return cartStoreItems.isEmpty(); // Check if the cart is empty
    }
}
