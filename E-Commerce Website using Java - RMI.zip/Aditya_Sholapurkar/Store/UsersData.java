package Store;

import Common.User;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class UsersData implements Serializable {
    private final List<User> administrators;
    private final List<User> customers;

    public UsersData () {
        this.administrators = new ArrayList<>();
        this.customers = new ArrayList<>();

        this.administrators.add(new User("admin", "admin123"));

        this.customers.add(new User("user01", "password"));
        this.customers.add(new User("user02", "password"));
    }

    public List<User> getAdministrators() {
        return administrators;
    }

    public List<User> getCustomers() {
        return customers;
    }
}
