package Store;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

import Store.Commands.*;
import Common.Command;
import Common.User;
import Common.UserAuth;

public class StoreUserManager extends UnicastRemoteObject implements UserAuth {

    private final UsersData usersData;

    public StoreUserManager() throws RemoteException {
        super();
        usersData = new UsersData();
    }

    @Override
    public boolean loginUser(User user, String loginType) throws RemoteException {
        switch (loginType) {
            case "admin":
                return checkAdminLogin(user);
            case "customer":
                return checkCustomerLogin(user);
            default:
                return false;
        }
    }

    private boolean checkAdminLogin(User user) throws RemoteException {
        for (User tempUser : usersData.getAdministrators())
            if (tempUser.getUsername().equalsIgnoreCase(user.getUsername()))
                if (tempUser.getPassword().equals(user.getPassword())) {
                    System.out.println("Admin logged in - " + user.getUsername());
                    return true;
                }
        return false;
    }

    private boolean checkCustomerLogin(User user) throws RemoteException {
        for (User tempUser : usersData.getCustomers())
            if (tempUser.getUsername().equalsIgnoreCase(user.getUsername()))
                if (tempUser.getPassword().equals(user.getPassword())) {
                    System.out.println("Customer logged in - " + user.getUsername());
                    return true;
                }
        return false;
    }

    @Override
    public void addCustomer(User user) throws RemoteException {
        Command addCustomerCommand = new AddCustomerCommand(usersData.getCustomers(), user);
        addCustomerCommand.execute();
        System.out.println("New customer - " + user.getUsername());
    }

    @Override
    public void removeCustomer(String username) throws RemoteException {
        Command removeCustomerCommand = new RemoveCustomerCommand(usersData.getCustomers(), username);
        removeCustomerCommand.execute();
        System.out.println("Removed customer - " + username);
    }

    @Override
    public void addAdministrator(User user) throws RemoteException {
        Command addAdministratorCommand = new AddAdministratorCommand(usersData.getAdministrators(), user);
        addAdministratorCommand.execute();
        System.out.println("New administrator - " + user.getUsername());
    }

    @Override
    public boolean isCustomer(String username) throws RemoteException {
        IsCustomerCommand isCustomerCommand = new IsCustomerCommand(usersData.getCustomers(), username);
        isCustomerCommand.execute();
        return isCustomerCommand.isResult();
    }

    @Override
    public boolean isAdministrator(String username) throws RemoteException {
        IsAdministratorCommand isAdministratorCommand = new IsAdministratorCommand(usersData.getAdministrators(), username);
        isAdministratorCommand.execute();
        return isAdministratorCommand.isResult();
    }
}
