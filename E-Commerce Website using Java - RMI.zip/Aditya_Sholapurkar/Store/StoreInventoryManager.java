package Store;

import Common.InventoryManager;
import Common.StoreItem;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;
import java.util.List;

public class StoreInventoryManager extends UnicastRemoteObject implements InventoryManager {
    private final Inventory storeInventory;

    public StoreInventoryManager() throws RemoteException {
        storeInventory = new Inventory();
    }

    @Override
    public List<StoreItem> getItems() throws RemoteException {
        return new ArrayList<>(storeInventory.getInventory()); // Return a copy to avoid external modifications
    }

    @Override
    public boolean isItemPresent(String name) throws RemoteException {
        return storeInventory.getInventory().stream()
                .anyMatch(storeItem -> storeItem.getName().equalsIgnoreCase(name));
    }

    @Override
    public void addItem(StoreItem storeItem) throws RemoteException {
        storeInventory.getInventory().add(storeItem);
        System.out.println("StoreItem " + storeItem.getName() + " added to inventory");
    }

    @Override
    public void removeItem(String name) throws RemoteException {
        storeInventory.getInventory().removeIf(item -> item.getName().equalsIgnoreCase(name));
        System.out.println("StoreItem " + name + " removed from inventory");
    }

    @Override
    public void updateItem(String name, double newPrice, int newQuantity) throws RemoteException {
        for (StoreItem item : storeInventory.getInventory()) {
            if (item.getName().equalsIgnoreCase(name)) {
                item.setPrice(newPrice);
                item.setQuantity(newQuantity);
                System.out.println("StoreItem " + name + " updated in inventory");
                return;
            }
        }
    }

    @Override
    public StoreItem getItemByName(String name) throws RemoteException {
        return storeInventory.getInventory().stream()
                .filter(storeItem -> storeItem.getName().equalsIgnoreCase(name))
                .findFirst()
                .orElse(null);
    }

    @Override
    public void purchaseItems(List<StoreItem> cart) throws RemoteException {
        for (StoreItem item: cart)
            this.updateItem(item.getName(), item.getPrice(), item.getQuantity()-1);

        this.checkOutOfStock();
    }

    private void checkOutOfStock() {
        storeInventory.getInventory().removeIf(item -> item.getQuantity() <= 0);
    }
}
