package Store;

import Common.StoreItem;

import java.util.ArrayList;
import java.util.List;

public class Inventory {
    private final List<StoreItem> inventory;

    public Inventory() {
        this.inventory = new ArrayList<>();

        this.inventory.add(new StoreItem("Laptop", 1200.00, 15));
        this.inventory.add(new StoreItem("USB-C cable", 9.99, 50));
        this.inventory.add(new StoreItem("Headphones", 99.99, 30));
    }

    public List<StoreItem> getInventory() {
        return inventory;
    }
}
