package Store.Commands;

import Common.Command;
import Common.User;

import java.util.List;

public class AddCustomerCommand implements Command {
    private final List<User> customers;
    private final User user;

    public AddCustomerCommand(List<User> customers, User user) {
        this.customers = customers;
        this.user = user;
    }
    @Override
    public void execute() {
        customers.add(user);
    }
}
