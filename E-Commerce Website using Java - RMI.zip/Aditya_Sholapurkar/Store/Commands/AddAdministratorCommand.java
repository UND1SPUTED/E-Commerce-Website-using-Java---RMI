package Store.Commands;

import Common.Command;
import Common.User;

import java.util.List;

public class AddAdministratorCommand implements Command {
    private final List<User> administrators;
    private final User user;

    public AddAdministratorCommand(List<User> administrators, User user) {
        this.administrators = administrators;
        this.user = user;
    }

    @Override
    public void execute() {
        administrators.add(user);
    }
}
