package Store.Commands;

import Common.Command;
import Common.User;

import java.util.List;

public class IsCustomerCommand implements Command {
    private  final  List<User> customers;
    private final String username;
    private boolean result;

    public IsCustomerCommand(List<User> customers, String username) {
        this.customers = customers;
        this.username = username;
    }
    @Override
    public void execute() {
        for (User user : customers)
            if (user.getUsername().equalsIgnoreCase(username)) {
                this.result = true;
                return;
            }
        this.result = false;
    }

    public boolean isResult() {
        return result;
    }
}
