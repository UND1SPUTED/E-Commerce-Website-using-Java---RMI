package Store.Commands;

import Common.Command;
import Common.User;

import java.util.List;

public class RemoveCustomerCommand implements Command {
    private final List<User> customers;
    private final String username;
    public RemoveCustomerCommand(List<User> customers, String username) {
        this.customers = customers;
        this.username = username;
    }

    @Override
    public void execute() {
        customers.removeIf(user -> user.getUsername().equalsIgnoreCase(username));
    }
}
