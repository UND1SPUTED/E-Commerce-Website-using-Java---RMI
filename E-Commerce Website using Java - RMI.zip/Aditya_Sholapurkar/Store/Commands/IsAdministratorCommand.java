package Store.Commands;

import Common.Command;
import Common.User;

import java.util.List;

public class IsAdministratorCommand implements Command {
    private final List<User> administrators;
    private final String username;
    private boolean result;


    public IsAdministratorCommand(List<User> administrators, String username) {
        this.administrators = administrators;
        this.username = username;
    }
    @Override
    public void execute() {
        for (User user : administrators)
            if (user.getUsername().equalsIgnoreCase(username)) {
                this.result = true;
                return;
            }
        this.result = false;
    }

    public boolean isResult() {
        return result;
    }
}
