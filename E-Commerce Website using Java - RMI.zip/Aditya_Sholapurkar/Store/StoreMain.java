package Store;

import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

import Common.InventoryManager;
import Common.UserAuth;

public class StoreMain {
    public static void main(String[] args) {
        try {
            int PORT_NUMBER = 2500;
            Registry registry = LocateRegistry.createRegistry(PORT_NUMBER);
            System.out.println("Server started");

            UserAuth userAuth = new StoreUserManager();
            hostUsers(registry, userAuth);

            InventoryManager inventoryManager = new StoreInventoryManager();
            hostInventory(registry, inventoryManager);

            System.out.println("Server running...");
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private static void hostUsers(Registry registry, UserAuth userAuth) throws RemoteException {
        registry.rebind("UserAuth", userAuth);
        System.out.println("UserAuth rebind Done!");
    }

    private static void hostInventory(Registry registry, InventoryManager productManager) throws RemoteException {
        registry.rebind("Inventory", productManager);
        System.out.println("Inventory rebind Done!");
    }
}
