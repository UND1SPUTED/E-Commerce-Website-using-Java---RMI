README.md for Assignment - 3
-----------------------------

Project Overview
----------------
This project simulates a client-server interaction where the server hosts a store and the client can select products and perform transactions. The project is structured to run across two machines: `rrpc1` for the server and `rrpc2` for the client.

Requirements
------------
- Two separate machines or environments (referred to as `rrpc-01` and `rrpc-02`) to simulate the server and client roles.


Setup Instructions
------------------

Setting Up the Store Server (on `rrpc-02`)
1. Navigate to the `Assignment-3` directory using command 'cd Assignment-3'.
2. Execute the following commands:
   make  # Cleans up any existing compiled classes and rebuilds the project.
   make server  # Starts the server.

Ensure that the server is running and waiting for client requests before proceeding to set up the client.

Setting Up the Client (on `rrpc-01`)
1. Assuming the classes were already compiled during the server setup, simply navigate to the `Assignment-3` directory.
2. Run the following command:
   make customer  # Initiates the client interface.

A menu will appear, allowing for various transactions to be performed with the server.
