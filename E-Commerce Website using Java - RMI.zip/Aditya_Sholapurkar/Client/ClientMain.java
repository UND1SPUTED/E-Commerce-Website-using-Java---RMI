package Client;

import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

import Common.*;

public class ClientMain {
    private static final int PORT_NUMBER = 2500;
    private static final String REGISTRY_HOST = "in-csci-rrpc02.cs.iupui.edu";

    public static void main(String[] args) throws Exception {
        try {
            System.out.println("Opening Online Store!");
            Registry registry = LocateRegistry.getRegistry(REGISTRY_HOST, PORT_NUMBER);

            UserAuth userAuth = (UserAuth) registry.lookup("UserAuth");
            System.out.println("UserAuth connected");
            InventoryManager inventoryManager = (InventoryManager) registry.lookup("Inventory");
            System.out.println("Inventory connected");

            ClientFront clientFront = new ClientFront(inventoryManager, userAuth);
            clientFront.startClient();
        } catch (Exception e) {
            System.out.println("Exception: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
