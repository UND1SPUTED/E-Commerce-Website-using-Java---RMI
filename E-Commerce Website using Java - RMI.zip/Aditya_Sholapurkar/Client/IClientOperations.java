package Client;

import java.rmi.RemoteException;

public interface IClientOperations {
    void startSession() throws RemoteException;
}
