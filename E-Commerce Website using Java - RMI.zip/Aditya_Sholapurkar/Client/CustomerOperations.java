package Client;

import Common.InventoryManager;
import Common.ShoppingCart;
import Common.StoreItem;

import java.rmi.RemoteException;
import java.util.Scanner;

public class CustomerOperations extends ClientOperations{
    ShoppingCart cart;

    public CustomerOperations(InventoryManager inventoryManager, Scanner scanner) {
        super(inventoryManager, scanner);
        cart = new ShoppingCart();
    }

    @Override
    public void startSession() throws RemoteException {
        super.startSession();
    }

    @Override
    protected void showOptions() {
        System.out.println("1.Add to cart \n2.Remove from cart \n3.View Items in cart \n4.Purchase Items in cart \n5.View Products \n6.Exit");
    }

    @Override
    protected boolean handleUserOption(int userOption) throws RemoteException {
        boolean isPresent;
        switch (userOption) {
            case 1: // Add to cart
                System.out.print("Enter item name to add to cart: ");
                String itemNameToAdd = scanner.nextLine();
                isPresent = inventoryManager.isItemPresent(itemNameToAdd);
                if (isPresent) {
                    StoreItem storeItemToAdd = inventoryManager.getItemByName(itemNameToAdd);
                    cart.addToCart(storeItemToAdd);
                    System.out.println(storeItemToAdd.getName() + " added to cart.");
                } else {
                    System.out.println("Item not found.");
                }
                break;
            case 2: // Remove from cart
                System.out.print("Enter item name to remove from cart: ");
                String itemNameToRemove = scanner.nextLine();
                isPresent = cart.isItemInCart(itemNameToRemove);
                if (isPresent) {
                    cart.removeFromCart(itemNameToRemove);
                    System.out.println(itemNameToRemove + " removed from cart.");
                } else {
                    System.out.println("Item not found in cart.");
                }
                break;
            case 3: // View items in cart
                if (cart.isEmpty()) {
                    System.out.println("Your cart is empty.");
                } else {
                    cart.getCartItems().forEach(storeItem -> System.out.println(storeItem.toString()));
                }
                break;
            case 4: // Purchase items in cart
                if (cart.isEmpty()) {
                    System.out.println("Your cart is empty.");
                } else {
                    System.out.println("Purchasing items in cart...");
                    inventoryManager.purchaseItems(cart.getCartItems());
                    System.out.println("Total: " + cart.getCartTotal());
                    cart.purchaseCart();
                    System.out.println("Purchase complete. Thank you!");
                }
                break;
            case 5: // View products
                System.out.println("Inventory items:");
                inventoryManager.getItems().forEach(storeItem -> System.out.println(storeItem.toString()));
                break;
            case 6: // Exit
                return false;
            default:
                System.out.println("Invalid input.");
                break;
        }
        return true;
    }
}
