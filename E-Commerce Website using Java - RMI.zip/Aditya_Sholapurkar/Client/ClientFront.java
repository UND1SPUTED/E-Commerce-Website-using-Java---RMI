package Client;

import Common.InventoryManager;
import Common.User;
import Common.UserAuth;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.InputMismatchException;
import java.util.Scanner;

import static java.lang.System.exit;

public class ClientFront extends UnicastRemoteObject {
    InventoryManager inventoryManager;
    Scanner scanner;
    UserAuth userAuth;
    IClientOperations clientOperations;

    public ClientFront(InventoryManager inventoryManager, UserAuth userAuth) throws RemoteException {
        super();
        this.inventoryManager = inventoryManager;
        this.userAuth = userAuth;

        scanner = new Scanner(System.in);
    }

    public void startClient() throws Exception {
        boolean continueSession = true;
        while (continueSession) {
            showMainOptions();
            int option;
            try {
                option = scanner.nextInt();
            } catch (InputMismatchException e) {
                System.out.println("Invalid input");
                scanner.nextLine();
                continue;
            }
            scanner.nextLine();
            continueSession = handleMainInput(option);
        }
        exit(0);
    }

    private void showMainOptions() {
        System.out.println("1.Customer 2.Admin 3.Exit");
    }

    private boolean handleMainInput(int choice) throws Exception {
        OperationsFactory operationsFactory = new OperationsFactory(inventoryManager, scanner, userAuth);
        switch (choice) {
            case 1: // Customer login
                if (!userAuth.loginUser(getUserDetails(), "customer")) {
                    System.out.println("Login failed.");
                    return true;
                }
                clientOperations = operationsFactory.getOperations("customer");
                break;
            case 2: // Admin login
                if (!userAuth.loginUser(getUserDetails(), "admin")) {
                    System.out.println("Login failed.");
                    return true;
                }
                clientOperations = operationsFactory.getOperations("admin");
                break;
            case 3: // Exit the application
                System.out.println("Exiting the application. Goodbye!");
                return false; // Return false to indicate that the session should end
            default:
                System.out.println("Invalid option. Please enter 1, 2, or 3.");
                break;
        }
        clientOperations.startSession();
        return true; // Return true to continue the session
    }

    private User getUserDetails() {
        System.out.print("Username: ");
        String username = scanner.nextLine();
        System.out.print("Password: ");
        String password = scanner.nextLine();

        return new User(username, password);
    }
}
