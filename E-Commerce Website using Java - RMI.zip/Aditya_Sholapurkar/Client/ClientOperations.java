package Client;

import Common.InventoryManager;

import java.rmi.RemoteException;
import java.util.InputMismatchException;
import java.util.Scanner;

public abstract class ClientOperations implements IClientOperations{
    protected Scanner scanner;
    protected InventoryManager inventoryManager;

    public ClientOperations(InventoryManager inventoryManager, Scanner scanner) {
        this.scanner = scanner;
        this.inventoryManager = inventoryManager;
    }
    @Override
    public void startSession() throws RemoteException {
        boolean continueSession = true;
        while (continueSession) {
            showOptions();
            int userOption;
            try {
                userOption = getUserOption();
            } catch (InputMismatchException e) {
                System.out.println("Invalid input");
                scanner.nextLine();
                continue;
            }
            continueSession = handleUserOption(userOption);
        }
    }

    private int getUserOption() throws InputMismatchException{
        int option = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        return option;
    }
    protected abstract void showOptions();
    protected abstract boolean handleUserOption(int userOption) throws RemoteException;
}
