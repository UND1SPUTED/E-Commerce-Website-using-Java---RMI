package Client;

import Common.InventoryManager;
import Common.StoreItem;
import Common.User;
import Common.UserAuth;

import java.rmi.RemoteException;
import java.util.InputMismatchException;
import java.util.Scanner;

public class AdminOperations extends ClientOperations{
    UserAuth userAuth;
    public AdminOperations(InventoryManager inventoryManager, Scanner scanner, UserAuth userAuth) {
        super(inventoryManager, scanner);
        this.userAuth = userAuth;
    }

    @Override
    public void startSession() throws RemoteException {
        super.startSession();
    }

    @Override
    protected void showOptions() {
        System.out.println("1.View Inventory \n2.Add Item \n3.Remove Item \n4.Update Item \n5.Add customer \n6.Remove customer \n7.Add administrator\n8.Exit");
    }

    @Override
    protected boolean handleUserOption(int userOption) throws RemoteException {
        String itemName;
        String username;
        String password;
        switch (userOption) {
            case 1: // View inventory
                System.out.println("Inventory items:");
                inventoryManager.getItems().forEach(storeItem -> System.out.println(storeItem.toString()));
                break;
            case 2: // Add item
                System.out.print("Enter item name: ");
                String name = scanner.nextLine().trim();
                if (name.isEmpty()){
                    System.out.println("Please enter name");
                    return true;
                }

                if (inventoryManager.isItemPresent(name)){
                    System.out.println("Item already exists");
                    return true;
                }

                System.out.println("Enter price:");
                double price;
                try {
                    price = scanner.nextDouble();
                } catch (InputMismatchException e) {
                    System.out.println("Invalid input");
                    scanner.nextLine();
                    return true;
                }
                System.out.print("Enter quantity: ");
                int quantity;
                try {
                    quantity = scanner.nextInt();
                } catch (InputMismatchException e) {
                    System.out.println("Invalid input");
                    scanner.nextLine();
                    return true;
                }
                scanner.nextLine(); // Consume the leftover newline
                inventoryManager.addItem(new StoreItem(name, price, quantity));
                System.out.println(name + " added to inventory.");
                break;
            case 3: // Remove item
                System.out.print("Enter item name to remove: ");
                itemName = scanner.nextLine();
                boolean isItemPresent = inventoryManager.isItemPresent(itemName);
                if (isItemPresent) {
                    inventoryManager.removeItem(itemName);
                    System.out.println(itemName + " removed from inventory.");
                } else {
                    System.out.println("Item not found.");
                }
                break;
            case 4: // Update item
                System.out.print("Enter item name to update: ");
                itemName = scanner.nextLine();
                boolean itemPresent = inventoryManager.isItemPresent(itemName);
                if (itemPresent) {
                    System.out.print("Enter new price: ");
                    double newPrice;
                    try {
                        newPrice = scanner.nextDouble();
                    } catch (InputMismatchException e) {
                        System.out.println("Invalid input");
                        scanner.nextLine();
                        return true;
                    }
                    System.out.print("Enter new quantity: ");
                    int newQuantity;
                    try {
                        newQuantity = scanner.nextInt();
                    } catch (InputMismatchException e) {
                        System.out.println("Invalid input");
                        scanner.nextLine();
                        return true;
                    }
                    scanner.nextLine(); // Consume the leftover newline
                    inventoryManager.updateItem(itemName, newPrice, newQuantity);
                    System.out.println(itemName + " updated.");
                } else {
                    System.out.println("Item not found.");
                }
                break;
            case 5: // Add customer
                System.out.print("Username: ");
                username = scanner.nextLine();

                if(userAuth.isCustomer(username)){
                    System.out.println("Customer already exists");
                    return true;
                }

                System.out.print("Password: ");
                password = scanner.nextLine();

                userAuth.addCustomer(new User(username, password));
                System.out.println("Customer " + username + " added.");
                break;
            case 6: // Remove customer (dummy functionality)
                System.out.print("Username: ");
                username = scanner.nextLine();

                if (!userAuth.isCustomer(username)) {
                    System.out.println("Customer not found");
                    return true;
                }

                userAuth.removeCustomer(username);
                System.out.println("Customer " + username + " removed.");
                break;
            case 7: // Add administrator
                System.out.print("Username: ");
                username = scanner.nextLine();

                if (userAuth.isAdministrator(username)){
                    System.out.println("Administrator already exists");
                    return true;
                }

                System.out.print("Password: ");
                password = scanner.nextLine();

                userAuth.addAdministrator(new User(username, password));
                System.out.println("New admin " + username + " added");
                break;
            case 8:
                return false;
            default:
                System.out.println("Invalid input.");
                break;
        }
        return true;
    }
}
