package Client;

import Common.InventoryManager;
import Common.UserAuth;

import java.util.Scanner;

public class OperationsFactory {
    InventoryManager inventoryManager;
    Scanner scanner;
    UserAuth userAuth;

    public OperationsFactory(InventoryManager inventoryManager, Scanner scanner, UserAuth userAuth) {
        this.inventoryManager = inventoryManager;
        this.scanner = scanner;
        this.userAuth = userAuth;
    }

    public IClientOperations getOperations(String loginType) throws Exception {
        switch (loginType) {
            case "admin":
                return new AdminOperations(inventoryManager, scanner, userAuth);
            case "customer":
                return new CustomerOperations(inventoryManager, scanner);
            default:
                throw new Exception("Invalid ClientOperations type.");
        }
    }
}
